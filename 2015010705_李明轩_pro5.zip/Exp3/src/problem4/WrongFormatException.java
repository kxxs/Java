package problem4;

public class WrongFormatException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6637925042614644383L;
	
	public WrongFormatException(String msg)  
    {  
        super(msg);  
    }  
}
