package problem4;

public class InputOutOfRangeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5584775791903480440L;

	public InputOutOfRangeException(String msg)  
    {  
        super(msg);  
    }  
}
