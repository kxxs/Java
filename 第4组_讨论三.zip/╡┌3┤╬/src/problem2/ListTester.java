import java.util.*;

class Elem {
    int num;
    public Elem() {
        num = (int) (Math.random() * 100);
    }
}

public class ListTester {
    public static void main(String[] args) {
        // 变量内存分配
        int i,n = 0xFFF;
        long timer;
        ArrayList<Elem> alist = new ArrayList();
        LinkedList<Elem> llist = new LinkedList();

        System.out.print("\t测试 ArrayList & LinkedList\t");

        /* ===================== *
         * 前序插入：LinkedList高效 *
         * ===================== */
        System.out.print("\r\n前序插入\t");

        // 前序插入：ArrayList *--------
        timer = System.currentTimeMillis(); i = n;
        while(i-->0) {
            alist.add(0, new Elem());
        }
        System.out.print("ArrayList：" + (System.currentTimeMillis() - timer) + "ms\t");

        // 前序插入：LinkedList *--------
        timer = System.currentTimeMillis(); i = n;
        while(i-->0)
            llist.add(0, new Elem());
        System.out.print("LinkedList：" + (System.currentTimeMillis() - timer) + "ms");

        /* ===================== *
         * 后序插入：复杂度同级      *
         * ===================== */
        System.out.print("\r\n后序插入\t");

        // 后序插入：ArrayList -------*
        timer = System.currentTimeMillis(); i = n;
        while(i-->0)
            alist.add(alist.size(), new Elem());
        System.out.print("ArrayList：" + (System.currentTimeMillis() - timer) + "ms\t");

        // 后序插入：LinkedList -------*
        timer = System.currentTimeMillis(); i = n;
        while(i-->0)
            llist.add(llist.size(), new Elem());
        System.out.print("LinkedList：" + (System.currentTimeMillis() - timer) + "ms");

        /* ===================== *
         * 随机插入：ArrayList高效  *
         * ===================== */
        System.out.print("\r\n随机插入\t");

        // 随机插入：ArrayList ----*---
        timer = System.currentTimeMillis(); i = n;
        while(i-->0)
            alist.add((int) (Math.random() * alist.size()), new Elem());
        System.out.print("ArrayList：" + (System.currentTimeMillis() - timer) + "ms\t");

        // 随机插入：LinkedList ----*---
        timer = System.currentTimeMillis(); i = n;
        while(i-->0)
            llist.add((int) (Math.random() * llist.size()), new Elem());
        System.out.print("LinkedList：" + (System.currentTimeMillis() - timer) + "ms");

        /* ===================== *
         * 顺序遍历：ArrayList高效  *
         * ===================== */
        System.out.print("\r\n顺序遍历\t");

        // 测试ArrayList顺序遍历
        timer = System.currentTimeMillis(); i = n;
        while(i-->0)
            alist.get(i).num++;
        System.out.print("ArrayList：" + (System.currentTimeMillis() - timer) + "ms\t");

        // 测试LinkedList遍历
        timer = System.currentTimeMillis(); i = n;
        while(i-->0) 
            llist.get(i).num++;
        System.out.print("LinkedList：" + (System.currentTimeMillis() - timer) + "ms");
    }
}