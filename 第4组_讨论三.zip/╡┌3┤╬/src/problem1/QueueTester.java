package problem1;

import java.util.*;
public class QueueTester {
    public static void main(String[] args) {
        Queue<Student> studentqueue=new LinkedList();
        Student student;
        Student student1=new Student("周杰伦","2016011888","工程物理系");
        Student student2=new Student("陈奕迅","2016010956","电机系");
        Student student3=new Student("Beyonce","2016011169","电子系");
        Student student4=new Student("Taylor","2016011137","美术学院");
        studentqueue.add(student1);
        studentqueue.add(student2);
        studentqueue.add(student3);
        studentqueue.add(student4);
        
        //poll()方法检测
        /*for(int i=(studentqueue.size()+1);i>0;i--){
            student=studentqueue.poll();
            if(student==null){
                System.out.println("null");
            }else
                student.output();
        }*/
        
        //remove()方法检测
        for(int i=(studentqueue.size()+1);i>0;i--){
            student=studentqueue.remove();
            if(student==null){
                System.out.println("null");
            }else
                student.output();
        }
    }
}
