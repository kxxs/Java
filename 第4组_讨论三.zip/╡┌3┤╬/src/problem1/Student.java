package problem1;

public class Student {
    String name;
    String id;
    String department;
    public Student(String a,String b,String c){
        this.name=a;
        this.id=b;
        this.department=c;
    }
    public void output(){
        System.out.println(this.name+"的学号是"+this.id+",来自"+this.department);
    }
}
