import problem1.Student;
import java.util.Stack;
import java.util.EmptyStackException;
class MyQueue<E>
{
    protected Stack<E> stack1=new Stack<E>();
    protected Stack<E> stack2=new Stack<E>();
    int size=0;
    public MyQueue()  {}
    public E insert(E elem)
    {
        size++;
        return stack1.push(elem);
    }
    public E remove() throws EmptyStackException
    {
        // 空栈异常
        if(size==0) throw new EmptyStackException();
        // 转存到 stack2 ， 头尾方向交换
        size--;
        for(int i=0;i<size;i++)
            stack2.push(stack1.pop());
        // 弹出 stack1 的最后一个元素
        E elem=stack1.pop();
        // 按原顺序放回
        for(int i=0;i<size;i++)
            stack1.push(stack2.pop());
        return elem;
    }
}

class IntpriorQueue<E> extends MyQueue<E>
{
    @Override
    public E insert(E elem)
    {
        int count=0;
        for(int i=0;i<size;i++)
            if((Integer)stack1.peek()>(Integer)elem && ++count>0)
                stack2.push(stack1.pop());
        stack1.push(elem);
        size++;
        for(int i=0;i<count;i++)
            stack1.push(stack2.pop());
        return elem;
    }
}
public class MyQueueTester {
    public static void main(String[] args) {
        MyQueue<Student> queue1=new MyQueue<Student>();
        Student student;
        Student student1=new Student("周杰伦","2016011888","工程物理系");
        Student student2=new Student("陈奕迅","2016010956","电机系");
        Student student3=new Student("Beyonce","2016011169","电子系");
        Student student4=new Student("Taylor","2016011137","美术学院");
        queue1.insert(student1);
        queue1.insert(student2);
        queue1.insert(student3);
        queue1.insert(student4);
        for(int i=0;i<4;i++){
            student=(Student)queue1.remove();
            student.output();
        }

        IntpriorQueue<Integer> queue2=new IntpriorQueue<Integer>();
        int random;
        for(int i=0;i<10;i++){
            random=(int)(Math.random()*100);
            System.out.printf("%d ",random);
            queue2.insert(random);
        }
        System.out.print('\n');
        for(int i=0;i<10;i++){
            System.out.printf("%d ",queue2.remove());
        }
    }
}
