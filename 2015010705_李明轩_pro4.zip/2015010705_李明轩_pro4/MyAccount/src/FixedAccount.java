
public final class FixedAccount extends Account {
	public String getReport(Date start,Date end,int reportType)
	{
		return null;
	}
}
