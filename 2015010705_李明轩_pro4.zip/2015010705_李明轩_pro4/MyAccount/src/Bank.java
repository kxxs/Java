
public class Bank extends Person {
    String homepage;
	Bank JSaccount=new Bank();
	public String getHomepage() {
		return homepage;
	}
	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}
}
