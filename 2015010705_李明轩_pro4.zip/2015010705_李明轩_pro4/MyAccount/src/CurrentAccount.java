
public final class CurrentAccount extends Account {
	public String getReport(Date start,Date end,int reportType)
	{
		return null;
	}
}
