
public final class TransferDeal extends Deal {

	Account inputAccount;
	Account outputAccount;
	Deal parseString(String dealString) {
		return null;
	}


	String ToPlainText() {
		return null;
	}


	public Account getInputAccount() {
		return inputAccount;
	}


	public void setInputAccount(Account inputAccount) {
		this.inputAccount = inputAccount;
	}


	public Account getOutputAccount() {
		return outputAccount;
	}


	public void setOutputAccount(Account outputAccount) {
		this.outputAccount = outputAccount;
	}
	
}
