
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyGraphics extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane = new JPanel();
	int offset = 0;
	int off = 10;
	
	class Anime implements Runnable{
		MyGraphics gra;
		public Anime(MyGraphics gra){
			this.gra = gra;
		}
		@Override
		public void run(){
			try { for (int i=0; i<6; i++,gra.paint(gra.getGraphics())) { Thread.sleep(100); } }
			catch (InterruptedException e) { e.printStackTrace(); }
		}
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyGraphics frame = new MyGraphics();
					ImageIcon icon = new ImageIcon("./src/2.png"); // 图片的路径
					frame.setIconImage(icon.getImage());
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	JButton button_happy, button_angry, button_sad, button_exit;
	String title = "表情小程序";
	public MyGraphics() {
		// JFrame settings
		setTitle(title);
		setFont(new Font("System", Font.PLAIN, 14));
		setBounds(100, 100, 600, 800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(contentPane);
		
		// set contentPane
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		// initialize button
		button_happy = new JButton("开心");
		button_angry = new JButton("生气");
		button_sad   = new JButton("伤心");
		button_exit  = new JButton("退出");
		
		// add buttons
		contentPane.add(button_exit);
		contentPane.add(button_sad);
		contentPane.add(button_happy);
		contentPane.add(button_angry);
		
		// add action listeners
		button_happy.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent arg0) { title = "开心"; repaint(); } });
		button_angry.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent arg0) { title = "生气"; repaint(); } });
		button_sad.  addActionListener(new ActionListener() { public void actionPerformed(ActionEvent arg0) { title = "伤心"; new Anime(MyGraphics.this).run(); } });
		button_exit. addActionListener(new ActionListener() { public void actionPerformed(ActionEvent arg0) { System.exit(0);           } });
	}

	public void paint(Graphics g) {
		super.paint(g); // call superclass's paint method
		setTitle(title);
		
		// 获取绘图区尺寸信息
		Rectangle s = this.getBounds();
		int x1 = (int) s.getMinX();
		int y1 = (int) s.getMinY();
		int height = (int) s.getHeight();
		int width = (int) s.getWidth();
		int midx = (int) s.getCenterX();
		int midy = (int) s.getCenterY();

		// 计算圆的半径
		int r = (width < height ? width : height) / 3;
		// 绘制按钮
		button_happy.setBounds(width * 1/9, height * 18/20 - 20, width / 9, 25);
		button_angry.setBounds(width * 3/9, height * 18/20 - 20, width / 9, 25);
		button_sad.  setBounds(width * 5/9, height * 18/20 - 20, width / 9, 25);
		button_exit. setBounds(width * 7/9, height * 18/20 - 20, width / 9, 25);

		g.drawOval(midx - r - x1, midy - r - y1, 2 * r, r * 2); // 绘制空心椭圆
		switch (title) {
		case "开心":
			// draw happy
			g.drawArc(midx - r * 5 / 6 - x1, midy - r / 3 - y1, r, r, 65,    50);
			g.drawArc(midx - r / 6 - x1,     midy - r / 3 - y1, r, r, 65,    50);
			g.drawArc(midx - r / 2 - x1,     midy - r / 3 - y1, r, r, -140, 100);
			break;
		case "生气":
			// draw angry
			g.drawLine(midx - r * 5 / 9 - x1, midy - r / 2 - y1, midx - r * 3 / 9 - x1, midy - r / 6 - y1);
			g.drawLine(midx - r * 3 / 9 - x1, midy - r / 6 - y1, midx - r * 1 / 9 - x1, midy - r / 2 - y1);
			g.drawLine(midx + r * 5 / 9 - x1, midy - r / 2 - y1, midx + r * 3 / 9 - x1, midy - r / 6 - y1);
			g.drawLine(midx + r * 3 / 9 - x1, midy - r / 6 - y1, midx + r * 1 / 9 - x1, midy - r / 2 - y1);
			g.drawLine(midx - r / 3 - x1, midy + r / 2 - y1, midx         - x1, midy + r / 7 - y1);
			g.drawLine(midx         - x1, midy + r / 7 - y1, midx + r / 3 - x1, midy + r / 2 - y1);
			break;
		case "伤心":
			// draw sad
			int h_eye = midy - r / 3 - y1;
			int l_eye = midx - r / 6 - x1;
			int r_eye = midx + r / 6 - x1;
			int x_mouse = midx - r / 2 - x1;
			int y_mouse = midy + r / 3 - y1;
			if( offset >  r / 6 ) off = -r / 12;
			if( offset < -r / 6 ) off =  r / 12;
			offset += off;
			g.drawLine(l_eye - r / 3 + offset, h_eye, r_eye - r / 3 + offset, h_eye);
			g.drawLine(l_eye + r / 3 + offset, h_eye, r_eye + r / 3 + offset, h_eye);
			g.drawArc( x_mouse + offset, y_mouse , r + (offset>0 ? -offset : offset), r, 40, 100);
			break;
		default:
			break;
		}
	}
}