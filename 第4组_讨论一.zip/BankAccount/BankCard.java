public class BankCard {
	private String id;				//银行卡号
	private String belongto;        //持卡人姓名
	private double balance;			//银行卡余额
	StringBuffer bill = new StringBuffer("## BankAccount bill:");		
									//银行账户信息

	public BankCard(String id) {
		this.id = id;
	}
	
	// 获取银行卡号
	public String getId() {
		return this.id;
	}
	
	// 设置银行卡号
	public void setId(String id) {
		this.id = id;
	}
	
	// 获取持卡人姓名
	public String getBelongto() {
		return this.belongto;
	}
	
	// 设置持卡人
	public void setBelongto(String belongto) {
		this.belongto = belongto;
	}
	
	// 获取余额
	public double getBalance() {
		return this.balance;
	}
	
	// 余额变动
    private void offsetBalance(double offset) {
		this.balance += offset;
	}
	
	// 转入一笔钱
	public double rollIn(double amount) {
		amount = (double) ((int)(amount * 100)) / 100;
		this.bill.append("\n# " + StudentAccount.getTimeStamp() + "  + ￥" + amount);
		this.offsetBalance(amount);
		return this.getBalance();
	}
	
	// 取款
	public double rollOut(double amount) {
		amount = (double) ((int)(amount * 100)) / 100;
		if (this.getBalance() - amount < 0) {
			System.err.println("\n* " + StudentAccount.getTimeStamp() 
			+" 余额不足，转出失败:\n** 当前余额："
		    + this.getBalance() + "\n** 目标转出：" + amount);
			return -1.0;
		}
		this.bill.append("\n# " + StudentAccount.getTimeStamp() + "  - ￥" + amount);
		this.offsetBalance(-amount);
		return this.getBalance();
	}
	
	// 取款（可附加信息）
	public double rollOut(double amount, String msg) {
		double ans = this.rollOut(amount);
		this.bill.append("\t" + msg);
		return ans;
	}
	
	//银行卡间转账(source为转出卡，target为转入卡，amount为转账金额)
	public static void bankTransfer(BankCard source,BankCard target,double amount)
	{
		amount = (double) ((int)(amount * 100)) / 100;
		if (source.getBalance() - amount < 0) 
			System.err.println("\n* " + StudentAccount.getTimeStamp() 
			                   +" 余额不足，转出失败:\n** 当前余额："
		                       + source.getBalance() + "\n** 目标转出：" + amount);
		else 
		{
			source.offsetBalance(-amount);
			target.offsetBalance(amount);
			source.bill.append("\n# " + StudentAccount.getTimeStamp() + "  - ￥" + amount);
			target.bill.append("\n# " + StudentAccount.getTimeStamp() + "  + ￥" + amount);
		}
		
	}
	
	// 获取银行卡账单信息
	public String getBill() {
		return this.bill.toString();
	}
}
