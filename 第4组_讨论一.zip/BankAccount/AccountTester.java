
public class AccountTester {
	public static void main(String args[]) {
		BankCard aCard = new BankCard("8350-1003-79767");
		BankCard bCard = new BankCard("8350-1003-79768");
		aCard.rollIn(8888);
		StudentAccount aStudent = new StudentAccount("J神","2015010233");
		aStudent.bindCard(aCard);
		aStudent.rollIn(233); 			              // 转入233元
		aStudent.rollOut(7.666666,"(QingFen Duck)");  // 吃了一只清芬香烤鸭
		aStudent.rollOut(800,"(Saber ShouBan!!!)");   // 买了一个Saber手办
		BankCard.bankTransfer(aCard,bCard,1000);        //a卡向b卡转账1000元
		System.out.println("\n银行卡账单：\n----------------------\n银行卡卡号："
				            +aCard.getId()+"\n\n"+aCard.getBill());
		System.out.println("\n银行卡余额：  "+aCard.getBalance());
		System.out.println("----------------------");
		System.out.println("\n\n----------------------\n银行卡卡号："
	                        +bCard.getId()+"\n\n"+bCard.getBill());
		System.out.println("\n银行卡余额：  "+bCard.getBalance());
		System.out.println("----------------------");
		System.out.println("\n学生卡信息：\n"+aStudent);
		System.out.println("\n学生卡账单：\n----------------------\n"
		                   +aStudent.getBill());
		System.out.println("\n学生卡余额：  "+aStudent.getBalance());
		System.out.println("----------------------");
		System.exit(0);
	}
}
