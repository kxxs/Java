import java.util.Date;
import java.text.SimpleDateFormat;  //显示当前时间所需要的包

public class StudentAccount {
	private String id;       //学号
	private String name;     //姓名
	private double balance;  //学生卡余额
	private BankCard card;   //银行卡类
	StringBuffer bill = new StringBuffer("## StudentAccount bill:");    
							 //学生账户信息

	// 初始化：姓名与学号
	public StudentAccount(String name, String id) {
		this.name=name;
		this.id  =id;
	}

	// 初始化：姓名
	public StudentAccount(String name) {
		this.name = name;
	}

	// toString 方法--学生身份信息
	public String toString() {
		return "----------------------------\n" 
	           + "| 学号：" + this.id
	           + "\n| 姓名：" + this.name 
	           + "\n| 卡号："+ this.getCard().getId()
	           + "\n----------------------------";

	}

	// 获取学号ID
	public String getId() {
		return this.id;
	}

	// 设置学号
	public void setId(String id) {
		this.id = id;
	}

	// 获取姓名
	public String getName() {
		return this.name;
	}

	// 设置姓名
	public void setName(String name) {
		this.name = name;
	}
	
	// 绑定银行卡
	public void bindCard(BankCard card) {
		this.card = card;
	}
	
	// 获取银行卡信息
	public BankCard getCard() {
		return this.card;
	}

	// 获取余额
	public double getBalance() {
		return this.balance;
	}

	// 余额变动
	private void offsetBalance(double offset) {
		this.balance += offset;
	}


	// 转入一笔钱（圈存）
	public double rollIn(double amount) {
		amount = (double) ((int) (amount * 100)) / 100;
	    if(this.getCard().rollOut(amount)==-1.0)
            {
	    	 amount=0;             //若银行卡余额不足，则圈存失败，学生卡余额无变动
             this.bill.append("\n# " + getTimeStamp() + "  银行卡余额不足，圈存失败" );
             }
        else this.bill.append("\n# " + getTimeStamp() + "  + ￥" + amount);
		
	    this.offsetBalance(amount);
		return this.getBalance();
	}

	// 消费一笔钱
	public double rollOut(double amount) {
		amount = (double)((int) (amount * 100))/100;
		
		if (this.getBalance() - amount < 0) {
			System.err.println("\n#"+getTimeStamp()+"  余额不足，消费失败:\n** 当前余额：" 
		                         + this.getBalance() + "\n** 目标消费：" + amount);
			this.bill.append("\n# " + getTimeStamp() + "  余额不足，消费失败");
			return -1.0;
		}
		else this.bill.append("\n# " + getTimeStamp() + "  - ￥" + amount);
		this.offsetBalance(-amount);
		return this.getBalance();
	}

	// 消费一笔钱，并记录消费信息
	public double rollOut(double amount, String msg) {
		double ans = this.rollOut(amount);
		this.bill.append("\t" + msg);
		return ans;
	}

	// 获取学生账单信息
	public String getBill() {
		return this.bill.toString();
	}

	// 获取当前时间戳
	public static String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss(SSS)");
		return sdf.format(new Date());
	}
}
